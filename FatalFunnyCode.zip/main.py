print('Hello, this is your password or secret safe, Unhackeble by FORTISNIGHIS')

a = str(input("Your username"))
b = str(input("Your password"))

if a == "a":
    print("Type your passwords here, only the ones that you least protect")

if b == "b":
    print(" most protected passwords")